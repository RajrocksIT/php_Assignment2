
<?php

?>
/**
* Created by PhpStorm.
* User: chinn
* Date: 10/08/2018
* Time: 12:23 AM
*/

<HTML>
<HEAD>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>
</HEAD>
<BODY>
<table style="width:100%">
    <tr>
        <th>Name</th>
        <th>UserName</th>
        <th>EmailAddress</th>
        <th>CellularNumber</th>
    </tr>
    <tr>
        <td>TyrionLannister</td>
        <td>HandOfGod1</td>
        <td>handofgod@got.com</td>
        <td>111-111-1111</td>
    </tr>
    <tr>
        <td>Aang</td>
        <td>TheLastAirBender</td>
        <td>iBendAirForFun@tlab.com</td>
        <td>000-000-0000</td>
    </tr>
    <tr>
        <td>FrodoBaggins</td>
        <td>Fbaggins</td>
        <td>fbaggins@lotr.com</td>
        <td>555-555-5555</td>
    </tr>
</table>

</BODY>
</HTML>
