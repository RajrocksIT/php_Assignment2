<?php
phpinfo();
?>


