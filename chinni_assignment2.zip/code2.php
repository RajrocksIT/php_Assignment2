
/**
 * Created by PhpStorm.
 * User: chinn
 * Date: 10/03/2018
 * Time: 1:35 PM
 */

<html>
<head>
    <title>My Second Program: Variable Assignment</title>
</head>
<body>
<?php
$string1 = 'First String assigned to a variable called $String1';
$string2 = 'Second String assigned to a variable called $String2';
echo "<h1>".$string1."</h1>";
echo "<h2>".$string2."</h2>";
?>
</body>
</html>