/**
* Created by PhpStorm.
* User: chinn
* Date: 10/08/2018
* Time: 12:23 AM
*/




<!DOCTYPE html>
<html>
<body>
&copy
<p>Rajesh Chinni.</p>
<?php

echo date("Y");

?>

Copyright.



</body>
</html>