
/**
 * Created by PhpStorm.
 * User: chinn
 * Date: 10/03/2018
 * Time: 1:24 PM
 */

<html>
<head>
    <title>My First Program</title>
</head>
<body>
<?php
echo "<h3>"."This is my first program"."</h3>";
echo "<h5>"."I am trying to print a string in the browser window"."</h5>";
?>
</body>
</html>