Installation of the current version of Node.js and Ganache and the following npm modules: ganache-cli, truffle, web3, solc, config and truffle-hdwallet-provider 

