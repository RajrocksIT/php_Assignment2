/**
* Created by PhpStorm.
* User: chinn
* Date: 10/08/2018
* Time: 12:23 AM
*/


<!DOCTYPE html>
<html>
<body>

<?php

$marks1 = array(360,310,310,330,313,375,456,111,256);
$marks2 = array(350,340,356,330,321);
$marks3 = array(630,340,570,635,434,255,298);

echo "maximum marks1 is ". max($marks1);
echo "</br>";
echo "maximum marks2 is ". max($marks2);
echo "</br>";
echo "maximum marks3 is ". max($marks3);
echo "</br>";

echo "minimum marks1 is ". min($marks1);
echo "</br>";
echo "minimum marks1 is ". min($marks2);
echo "</br>";
echo "minimum marks1 is ". min($marks3);
echo "</br>";


?>

</body>
</html>