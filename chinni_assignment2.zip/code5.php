
/**
 * Created by PhpStorm.
 * User: chinn
 * Date: 10/03/2018
 * Time: 1:56 PM
 */

<!DOCTYPE html>
<html>
<body>

<?php

$scriptname = $_SERVER['SERVER_PROTOCOL'];
echo "Is it http or https?"."<br><br>";
echo $scriptname;

?>

</body>
</html>